const admin = require('../config/firebase');

async function authMiddleware(req, res, next) {
  const header = req.headers['authorization'] || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' });
  }

  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = {
      uid: decoded.uid,
      email: decoded.email || null,
      name: decoded.name || null
    };
    next();
  } catch (err) {
    console.error('[auth] verifyIdToken error', err);
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = authMiddleware;
