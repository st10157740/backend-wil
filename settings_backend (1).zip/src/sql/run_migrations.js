require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { getPool } = require('../config/db');

(async () => {
  try {
    const pool = await getPool();
    const schemaPath = path.join(__dirname, 'schema.sql');
    const sql = fs.readFileSync(schemaPath, 'utf8');
    // Split by GO for SQL Server batches
    const batches = sql.split(/\bGO\b/i).map(s => s.trim()).filter(Boolean);

    for (const b of batches) {
      await pool.request().batch(b);
    }
    console.log('[migrate] schema applied');
    process.exit(0);
  } catch (e) {
    console.error('[migrate] error', e);
    process.exit(1);
  }
})();
