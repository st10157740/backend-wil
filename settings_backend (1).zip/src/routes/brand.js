function detectBrand(number='') {
  const n = number.replace(/\s|-/g, '');
  if (/^4\d{12}(\d{3})?(\d{3})?$/.test(n)) return 'VISA';
  if (/^(5[1-5]\d{4}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{10}$/.test(n)) return 'Mastercard';
  if (/^3[47]\d{13}$/.test(n)) return 'AMEX';
  if (/^6(?:011|5\d{2})\d{12}$/.test(n)) return 'Discover';
  return 'Card';
}
module.exports = { detectBrand };
