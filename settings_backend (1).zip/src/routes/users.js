const router = require('express').Router();
const auth = require('../middleware/auth');
const { sql, getPool } = require('../config/db');
const { detectBrand } = require('./brand');

// Ensure user row exists; create if not found
async function findOrCreateUserByUid(pool, uid, email, name) {
  let result = await pool.request()
    .input('FirebaseUid', sql.NVarChar(128), uid)
    .query('SELECT TOP 1 * FROM Users WHERE FirebaseUid = @FirebaseUid');

  if (result.recordset.length === 0) {
    // Create
    const insert = await pool.request()
      .input('FirebaseUid', sql.NVarChar(128), uid)
      .input('Email', sql.NVarChar(255), email || '')
      .input('Name', sql.NVarChar(100), name || '')
      .query(`INSERT INTO Users (FirebaseUid, Email, Name) 
              OUTPUT inserted.*
              VALUES (@FirebaseUid, @Email, @Name)`);
    return insert.recordset[0];
  }
  return result.recordset[0];
}

// GET /users/me
router.get('/me', auth, async (req, res) => {
  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    return res.json({
      id: userRow.Id,
      name: userRow.Name,
      email: userRow.Email,
      phone: userRow.Phone
    });
  } catch (e) {
    console.error('[GET /users/me] error', e);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// PUT /users/me  { name, phone }
router.put('/me', auth, async (req, res) => {
  const { name, phone } = req.body || {};
  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    const update = await pool.request()
      .input('Id', sql.UniqueIdentifier, userRow.Id)
      .input('Name', sql.NVarChar(100), name || userRow.Name)
      .input('Phone', sql.NVarChar(30), phone || null)
      .query(`UPDATE Users SET Name=@Name, Phone=@Phone, UpdatedAt=SYSUTCDATETIME() WHERE Id=@Id;
              SELECT * FROM Users WHERE Id=@Id;`);

    const u = update.recordset[0];
    res.json({ id: u.Id, name: u.Name, email: u.Email, phone: u.Phone });
  } catch (e) {
    console.error('[PUT /users/me] error', e);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// GET /users/me/payment-methods
router.get('/me/payment-methods', auth, async (req, res) => {
  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    const result = await pool.request()
      .input('UserId', sql.UniqueIdentifier, userRow.Id)
      .query('SELECT * FROM PaymentMethods WHERE UserId=@UserId ORDER BY CreatedAt DESC');

    const items = result.recordset.map(pm => ({
      id: pm.Id,
      brand: pm.Brand,
      last4: pm.Last4,
      expMonth: pm.ExpMonth,
      expYear: pm.ExpYear
    }));
    res.json(items);
  } catch (e) {
    console.error('[GET /users/me/payment-methods] error', e);
    res.status(500).json({ error: 'Failed to list payment methods' });
  }
});

// POST /users/me/payment-methods  { number, expMonth, expYear, cvc }
router.post('/me/payment-methods', auth, async (req, res) => {
  const { number, expMonth, expYear } = req.body || {};
  if (!number || !expMonth || !expYear) {
    return res.status(400).json({ error: 'number, expMonth, expYear required' });
  }

  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    const digits = String(number).replace(/\s|-/g, '');
    const last4 = digits.slice(-4);
    const brand = detectBrand(digits);

    const insert = await pool.request()
      .input('UserId', sql.UniqueIdentifier, userRow.Id)
      .input('Brand', sql.NVarChar(50), brand)
      .input('Last4', sql.NVarChar(4), last4)
      .input('ExpMonth', sql.Int, expMonth)
      .input('ExpYear', sql.Int, expYear)
      .query(`INSERT INTO PaymentMethods (UserId, Brand, Last4, ExpMonth, ExpYear)
              OUTPUT inserted.*
              VALUES (@UserId, @Brand, @Last4, @ExpMonth, @ExpYear);`);

    const pm = insert.recordset[0];
    res.status(201).json({
      id: pm.Id, brand: pm.Brand, last4: pm.Last4, expMonth: pm.ExpMonth, expYear: pm.ExpYear
    });
  } catch (e) {
    console.error('[POST /users/me/payment-methods] error', e);
    res.status(500).json({ error: 'Failed to add payment method' });
  }
});

// DELETE /users/me/payment-methods/:id
router.delete('/me/payment-methods/:id', auth, async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    // ensure it belongs to this user
    const check = await pool.request()
      .input('Id', sql.UniqueIdentifier, id)
      .input('UserId', sql.UniqueIdentifier, userRow.Id)
      .query('SELECT TOP 1 * FROM PaymentMethods WHERE Id=@Id AND UserId=@UserId');

    if (check.recordset.length === 0) return res.status(404).json({ error: 'Not found' });

    await pool.request()
      .input('Id', sql.UniqueIdentifier, id)
      .query('DELETE FROM PaymentMethods WHERE Id=@Id');

    res.status(204).end();
  } catch (e) {
    console.error('[DELETE /users/me/payment-methods/:id] error', e);
    res.status(500).json({ error: 'Failed to delete payment method' });
  }
});

// POST /users/me/deactivate
router.post('/me/deactivate', auth, async (req, res) => {
  try {
    const pool = await getPool();
    const userRow = await findOrCreateUserByUid(pool, req.user.uid, req.user.email, req.user.name);

    await pool.request()
      .input('Id', sql.UniqueIdentifier, userRow.Id)
      .query('UPDATE Users SET IsActive=0, UpdatedAt=SYSUTCDATETIME() WHERE Id=@Id');

    res.status(200).json({ ok: true });
  } catch (e) {
    console.error('[POST /users/me/deactivate] error', e);
    res.status(500).json({ error: 'Failed to deactivate account' });
  }
});

module.exports = router;
