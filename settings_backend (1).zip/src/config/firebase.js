const admin = require('firebase-admin');

// Prefer Application Default Credentials (recommended):
// export GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccount.json
try {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: process.env.FIREBASE_PROJECT_ID
  });
  console.log('[firebase] initialized using ADC');
} catch (e) {
  console.error('[firebase] initialization error', e);
  throw e;
}

module.exports = admin;
