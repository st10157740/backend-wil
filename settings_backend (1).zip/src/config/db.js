const sql = require('mssql');

const config = {
  server: process.env.MSSQL_SERVER,
  database: process.env.MSSQL_DATABASE,
  user: process.env.MSSQL_USER,
  password: process.env.MSSQL_PASSWORD,
  options: {
    encrypt: (process.env.MSSQL_ENCRYPT || 'false').toLowerCase() === 'true',
    trustServerCertificate: true
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

let poolPromise;

async function getPool() {
  if (!poolPromise) {
    poolPromise = sql.connect(config).then(pool => {
      console.log('[mssql] connected');
      return pool;
    }).catch(err => {
      console.error('[mssql] connection error:', err);
      throw err;
    });
  }
  return poolPromise;
}

module.exports = { sql, getPool };
