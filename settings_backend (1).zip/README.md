# Settings Backend (Node.js + Express + SQL Server + Firebase Auth)

This API matches the Android **Settings** feature I shipped. It provides:

- `GET /users/me` — fetch current user
- `PUT /users/me` — update profile (name, phone)
- `GET /users/me/payment-methods` — list cards
- `POST /users/me/payment-methods` — add card (stores only brand + last4 + exp)
- `DELETE /users/me/payment-methods/:id` — remove card
- `POST /users/me/deactivate` — deactivate account
- `GET /health` — health check

## Quick start

1. **Node version**: 18+
2. Copy `.env.example` to `.env` and fill in values.
3. Ensure your SQL Server is reachable.
4. Create tables:
   ```bash
   npm run migrate
   ```
5. Start the API:
   ```bash
   npm install
   npm run dev   # or: npm start
   ```

## Firebase Auth

The API expects a Firebase ID token in `Authorization: Bearer <token>`.
Configure credentials via one of the following:

- Set `GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccountKey.json`
- Or edit `src/config/firebase.js` to load from env values

## SQL Server schema

See `src/sql/schema.sql` and `src/sql/sample_data.sql`.
